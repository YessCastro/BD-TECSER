function toggleMenu() {
    const menu = document.getElementById('menu');
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}

function mostrarFormulario(tabla) {
    alert('Gestionar la tabla: ' + tabla);
    // Aquí iría la lógica para mostrar el CRUD de la tabla seleccionada.
}
